from flask import Flask, jsonify, request
import csv 
from demographic import output
from content import get_rec

all_movies = []

with open('final.csv', encoding = "utf-8") as f:
    reader = csv.reader(f)
    data = list(reader)

    all_movies = data[1:]

liked_movies = []
disliked_movies = []
dnw_movies = []
#dnw -> did not watch

app = Flask(__name__)

@app.route('/get-movie')

def get_movie():
    global all_movies

    movie_data = {'title': all_movies[0][8], 
                  'poster_link': all_movies[0][27], 
                  'release_date': all_movies[0][13] or "NA", 
                  'runtime': all_movies[0][15], 
                  'vote_average': all_movies[0][20], 
                  'overview': all_movies[0][9]}
    return jsonify({
        'data': movie_data,
        'status': "success"
    })

@app.route('/liked-movies', methods = ["POST"])

def like_movie():
    global all_movies

    movie = all_movies[0]
    all_movies = all_movies[1:]

    liked_movies.append(movie)
    return jsonify({'status': "success"}), 201

@app.route('/disliked-movies', methods = ["POST"])

def dislike_movie():
    global all_movies

    movie = all_movies[0]
    all_movies = all_movies[1:]

    disliked_movies.append(movie)
    return jsonify({'status': "success"}), 201

@app.route('/dnw-movies', methods = ["POST"])

def dnw_movie():
    global all_movies
    
    movie = all_movies[0]
    all_movies = all_movies[1:]

    dnw_movies.append(movie)
    return jsonify({'status': "success"}), 201


@app.route('/popular-movies')

def popular_movies():
    movie_data = []
    for movie in output:
        d = {'title': movie[0], 
             'poster_link': movie[1], 
             'release_date': movie[2] or "NA", 
             'runtime': movie[3], 
             'vote_average': movie[4], 
             'overview': movie[5]}
        movie_data.append(d)
    return jsonify({
        'data': movie_data,
        'status': "success"
    })


@app.route('/recommended-movies')

def recommended_movies():
    all_recommended = []

    for movie in liked_movies:
        output = get_rec(movie)
        for i in output:
            all_recommended.append(i)
    
    import itertools
    all_recommended.sort()
    all_recommended = list(all_recommended for all_recommended, _ in itertools.groupby(all_recommended))
    movie_data = []

    for movie in all_recommended:
        d = {'title': movie[0], 
             'poster_link': movie[1], 
             'release_date': movie[2] or "NA", 
             'runtime': movie[3], 
             'vote_average': movie[4], 
             'overview': movie[5]}
        movie_data.append(d)

    return jsonify({
        'data': movie_data,
        'status': "success"
    })


if __name__ == "__main__":
    app.run()

