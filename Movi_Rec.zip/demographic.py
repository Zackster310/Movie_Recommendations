import pandas as pd

df = pd.read_csv("final.csv")

c = df['vote_average'].mean()

m = df['vote_count'].quantile(0.9)

eligible_movies = df.copy().loc[df['vote_count'] >= m]

eligible_movies.shape

def weighted_rating(movie, m = m, c = c):
  v = movie['vote_count']
  r = movie['vote_average']

  return(
      (v / (v+m)) * r + (m / (m+v)) * c
  )

eligible_movies['score'] = eligible_movies.apply(weighted_rating, axis = 1)

eligible_movies = eligible_movies.sort_values('score', ascending = False)

output = eligible_movies[['title', 'poster_link', 'release_date', 'runtime', 'vote_average', 'overview']].head(20).values.tolist()