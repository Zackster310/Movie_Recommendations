import csv

with open('movies.csv', encoding = "utf-8") as f:
    reader = csv.reader(f)
    data = list(reader)

    all_movies = data[1:]
    headers = data[0]
    
headers.append("poster_link")

with open('final.csv', "w", encoding = "utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(headers)

with open('movie_links.csv', encoding = "utf-8") as f:
    reader = csv.reader(f)
    p_data = list(reader)

    all_movie_links = p_data[1:]

for item in all_movies:
    poster_found = any(item[8] in links for links in all_movie_links)

    if poster_found:
        for i in all_movie_links:
            if item[8] == i[0]:
                item.append(i[1])

                if len(item) == 28:
                    with open('final.csv', "a+", encoding = "utf-8") as f:
                        writer = csv.writer(f)
                        writer.writerow(item)

    